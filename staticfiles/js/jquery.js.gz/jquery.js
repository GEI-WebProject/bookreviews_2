$(function () {
    $("#rateYo").rateYo({
        readOnly: true,
        rating: 3,
        fullStar: true
    });
});